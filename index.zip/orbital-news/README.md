# 🔭 Orbital News

**Periodismo científico autónomo generado por IA.**  
Noticias reales de ciencia, cada día, publicadas automáticamente en GitHub Pages.

Un proyecto de [Con F de Física](https://confdefisica.space).

---

## ¿Cómo funciona?

1. Cada día a las **7:00 AM** (hora de España), GitHub Actions se activa automáticamente
2. **Claude IA** busca las noticias científicas más importantes del día en la web
3. Se genera el `index.html` con el diseño de Orbital News
4. El sitio se publica automáticamente en GitHub Pages

---

## Instalación paso a paso

### 1. Crear el repositorio en GitHub

```bash
# En GitHub, crear un repo llamado "orbital-news" (puede ser público o privado)
# Luego clonar y subir estos archivos:
git init
git add .
git commit -m "🚀 Orbital News — primera versión"
git remote add origin https://github.com/TU_USUARIO/orbital-news.git
git push -u origin main
```

### 2. Añadir la API Key de Anthropic como Secret

1. Ve a tu repositorio en GitHub
2. **Settings** → **Secrets and variables** → **Actions**
3. Clic en **New repository secret**
4. Nombre: `ANTHROPIC_API_KEY`
5. Valor: tu API key de Anthropic (empieza por `sk-ant-...`)
6. Clic en **Add secret**

### 3. Activar GitHub Pages

1. Ve a **Settings** → **Pages**
2. En "Source", selecciona **Deploy from a branch**
3. Branch: `main` / Folder: `/ (root)`
4. Guarda

Tu sitio estará en: `https://TU_USUARIO.github.io/orbital-news/`

### 4. Primera publicación manual

Para probar que todo funciona antes de esperar al día siguiente:

1. Ve a **Actions** en tu repositorio
2. Selecciona "Orbital News — Publicación diaria"
3. Clic en **Run workflow** → **Run workflow**
4. Espera ~2 minutos y recarga tu sitio

---

## Estructura del proyecto

```
orbital-news/
├── index.html              # Página generada automáticamente (no editar)
├── data/
│   ├── latest.json         # Noticias del día actual
│   └── news_YYYY-MM-DD.json # Archivo histórico por fecha
├── scripts/
│   ├── generate_news.py    # Llama a Claude API y obtiene noticias reales
│   └── build_html.py       # Convierte el JSON en el HTML del sitio
├── .github/
│   └── workflows/
│       └── daily-news.yml  # Automatización diaria
└── README.md
```

---

## Personalización

### Cambiar el horario de publicación

En `.github/workflows/daily-news.yml`, modifica la línea `cron`:
```yaml
- cron: '0 5 * * *'   # 7:00 AM España (UTC+2 verano)
- cron: '0 6 * * *'   # 8:00 AM España (UTC+1 invierno)
```

### Cambiar la temática

En `scripts/generate_news.py`, edita el `SYSTEM_PROMPT` para enfocar en temas específicos:
- Solo astronomía y física
- Noticias de España
- Ciencia y tecnología
- etc.

### Añadir tu dominio personalizado

1. En **Settings** → **Pages** → **Custom domain**, añade tu dominio
2. Crea un archivo `CNAME` en la raíz con tu dominio:
   ```
   orbital-news.confdefisica.space
   ```

---

## Coste estimado

| Concepto | Coste |
|----------|-------|
| GitHub Actions | Gratis (2000 min/mes incluidos) |
| GitHub Pages | Gratis |
| Claude API (por edición) | ~$0.02–0.05 USD |
| **Total mensual** | **~$0.60–1.50 USD** |

---

## Créditos

- Diseño y concepto: **Con F de Física**  
- Generación de contenido: **Claude (Anthropic)**  
- Infraestructura: **GitHub Pages + Actions**
