#!/usr/bin/env python3
"""
Orbital News — Generador automático de noticias con Claude API + web search
Uso: python scripts/generate_news.py
Requiere: ANTHROPIC_API_KEY en variables de entorno
"""

import os
import json
import datetime
import re
import sys
import urllib.request
import urllib.error

API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
if not API_KEY:
    print("ERROR: ANTHROPIC_API_KEY no definida", file=sys.stderr)
    sys.exit(1)

TODAY = datetime.date.today()
DATE_ES = {
    "days": ["Lunes","Martes","Miércoles","Jueves","Viernes","Sábado","Domingo"],
    "months": ["enero","febrero","marzo","abril","mayo","junio",
               "julio","agosto","septiembre","octubre","noviembre","diciembre"]
}
weekday = TODAY.weekday()  # 0=Lunes
day_name = DATE_ES["days"][weekday]
month_name = DATE_ES["months"][TODAY.month - 1]
date_str = f"{day_name}, {TODAY.day} de {month_name} de {TODAY.year}"

SYSTEM_PROMPT = """Eres el sistema de generación de contenido de Orbital News, 
un medio de divulgación científica en español. Tu tarea es buscar noticias científicas 
reales y recientes (últimas 48 horas) y redactarlas de forma clara, rigurosa y accesible.

IMPORTANTE: Usa la herramienta web_search para buscar noticias REALES de hoy o ayer.
No inventes noticias. Si no encuentras algo reciente sobre un tema, elige otro.

Responde ÚNICAMENTE con un objeto JSON válido, sin texto adicional, sin bloques de código markdown.
El JSON debe tener exactamente esta estructura:

{
  "ticker": ["titular corto 1", "titular corto 2", "titular corto 3", "titular corto 4", "titular corto 5", "titular corto 6"],
  "hero": {
    "categoria": "Astronomía",
    "titulo": "Título principal impactante",
    "deck": "Párrafo de 2-3 frases que explica la noticia con más detalle.",
    "minutos_lectura": 3
  },
  "lateral": [
    {"categoria": "Física", "titulo": "Título noticia 2", "resumen": "1-2 frases."},
    {"categoria": "Biología", "titulo": "Título noticia 3", "resumen": "1-2 frases."},
    {"categoria": "Tecnología", "titulo": "Título noticia 4", "resumen": "1-2 frases."}
  ],
  "columnas": [
    {"num": "01", "categoria": "Clima", "titulo": "Título", "resumen": "2-3 frases."},
    {"num": "02", "categoria": "Neurociencia", "titulo": "Título", "resumen": "2-3 frases."},
    {"num": "03", "categoria": "Espacio", "titulo": "Título", "resumen": "2-3 frases."}
  ],
  "profundidad": {
    "categoria": "Mecánica Orbital",
    "titulo": "Título del artículo de análisis más profundo",
    "resumen": "3-4 frases explicando el análisis.",
    "minutos_lectura": 8
  },
  "mini": [
    {"categoria": "Química", "titulo": "Título breve"},
    {"categoria": "Geofísica", "titulo": "Título breve"},
    {"categoria": "Computación", "titulo": "Título breve"},
    {"categoria": "Medicina", "titulo": "Título breve"}
  ],
  "editorial": "Frase reflexiva sobre la ciencia de hoy (entre comillas en el JSON, máx 25 palabras).",
  "stats": [
    {"valor": "4,812", "label": "Artículos científicos publicados hoy"},
    {"valor": "1,247", "label": "Satélites activos en órbita"},
    {"valor": "3.8 cm", "label": "Distancia Luna-Tierra ganada este año"},
    {"valor": "7", "label": "Exoplanetas descubiertos esta semana"}
  ]
}"""

USER_PROMPT = f"""Fecha de hoy: {date_str}

Busca las noticias científicas más importantes e interesantes de hoy o ayer ({TODAY.strftime('%Y-%m-%d')}).
Cubre diversidad de campos: astronomía, física, biología, neurociencia, clima, tecnología, medicina, etc.
Prioriza descubrimientos, publicaciones en revistas científicas, misiones espaciales, y avances tecnológicos.
El artículo de 'profundidad' debe ser el más interesante del día, con análisis más elaborado.
El editorial debe ser una reflexión poética o filosófica sobre alguna de las noticias del día.
Responde SOLO con el JSON, sin ningún texto antes o después."""

def call_claude():
    payload = {
        "model": "claude-opus-4-5",
        "max_tokens": 4000,
        "tools": [{"type": "web_search_20250305", "name": "web_search"}],
        "system": SYSTEM_PROMPT,
        "messages": [{"role": "user", "content": USER_PROMPT}]
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=data,
        headers={
            "Content-Type": "application/json",
            "x-api-key": API_KEY,
            "anthropic-version": "2023-06-01",
            "anthropic-beta": "web-search-2025-03-05"
        },
        method="POST"
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        return json.loads(resp.read().decode("utf-8"))

def extract_json(response):
    """Extrae el JSON de la respuesta de Claude (puede venir tras tool_use blocks)"""
    text = ""
    for block in response.get("content", []):
        if block.get("type") == "text":
            text = block["text"]
    # Limpiar posibles bloques markdown
    text = re.sub(r"```json\s*", "", text)
    text = re.sub(r"```\s*", "", text)
    text = text.strip()
    return json.loads(text)

def main():
    print(f"🔭 Orbital News — Generando edición del {date_str}...")
    
    print("📡 Llamando a Claude API con web search...")
    try:
        response = call_claude()
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        print(f"ERROR HTTP {e.code}: {body}", file=sys.stderr)
        sys.exit(1)

    print("✍️  Extrayendo JSON de noticias...")
    try:
        news = extract_json(response)
    except (json.JSONDecodeError, KeyError) as e:
        print(f"ERROR parseando JSON: {e}", file=sys.stderr)
        # Debug: mostrar respuesta cruda
        for block in response.get("content", []):
            if block.get("type") == "text":
                print("Texto recibido:", block["text"][:500], file=sys.stderr)
        sys.exit(1)

    # Añadir metadatos
    news["meta"] = {
        "date_iso": TODAY.isoformat(),
        "date_es": date_str,
        "edition": TODAY.strftime("%Y%m%d")
    }

    # Guardar JSON
    os.makedirs("data", exist_ok=True)
    out_path = f"data/news_{TODAY.isoformat()}.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(news, f, ensure_ascii=False, indent=2)
    
    # También guardar como latest.json
    with open("data/latest.json", "w", encoding="utf-8") as f:
        json.dump(news, f, ensure_ascii=False, indent=2)

    print(f"✅ Noticias guardadas en {out_path}")
    print(f"   Hero: {news['hero']['titulo'][:60]}...")
    return news

if __name__ == "__main__":
    main()
